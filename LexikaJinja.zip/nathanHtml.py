from jinja2 import Environment, FileSystemLoader
from jinja2 import Template
import csv
from IntroJinja_modele import *

def creer_html(fichier_template, fichier_sortie, fichier_csv) :
    env = Environment(loader = FileSystemLoader("."), trim_blocks = True)
    template = env.get_template(fichier_template)
    html = template.render(fichier_csv)
    f = open(fichier_sortie, 'w')
    f.write(html)
    f.close()

#appels de la fonction creer_html
creer_html("IntroJinja_template.html", "select.html","select.csv"
          )


#https://stackoverflow.com/questions/1017898/formatting-csv-file-data-with-html-template


